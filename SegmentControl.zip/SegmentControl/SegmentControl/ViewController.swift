//
//  ViewController.swift
//  SegmentControl
//
//  Created by Rp on 28/11/18.
//  Copyright © 2018 Rp. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var segment : UISegmentedControl!
    
    let arr = ["A1","A2","A3","A4"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let segmentSecount = UISegmentedControl.init(items: arr)
        segmentSecount.frame = CGRect.init(x: 20, y: 40, width: UIScreen.main.bounds.size.width-40, height: 30)
        segmentSecount.backgroundColor = UIColor.black
        segmentSecount.tintColor = UIColor.red
        view.addSubview(segmentSecount)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

